<footer class="bg-white border-t border-gray-200 mt-12 py-6">
    <div class="max-w-7xl mx-auto px-4 text-center text-sm text-gray-500">
        &copy; <?= date('Y') ?> Maulana Zidane. Semua hak dilindungi.
    </div>
</footer>