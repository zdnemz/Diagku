<?php
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'tugas_akhir',
        'user' => 'root',
        'pass' => '',
    ]
];
